/*
    Aufgabe 1) Codeanalyse, Codingstyle und Methoden
*/
public class Aufgabe1 {
    
    public static String f0(String s) {
        
        int n = f1(s);
        for (int i = 1;
                i < n;
             i = f2(i)) {
            char k = s.charAt(i);int j = f3(i);
            while (
                    f4(j, 0)
                            &&
                            f5(s.charAt(j), k)) {
                j = f3(j);
            }
            j = f2(j);
            s = f6(s, 0, j) +
                k +
                    f6(s, j, i) +
                f6(s, i +
                1, s.length());
        }
        return s;
    }
    
    public static int f1(String s) {
        return s.length();
    }
    
    public static int f2(int n) {
        return n + 1;
    }
    
    public static int f3(int n) {
        return n - 1;
    }
    
    public static boolean f4(int n1, int n2) {
        return n1 >= n2;
    }
    
    public static boolean f5(char c1, char c2) {
        return c1 >= c2;
    }
    
    public static String f6(String s, int n1, int n2) {
        return s.substring(n1, n2);
    }
    
    public static void main(String args[]) {
        System.out.println(f0("ab"));
        System.out.println(f0("ba"));
        System.out.println(f0("aa"));
        System.out.println(f0("cba"));
        System.out.println(f0("abababab"));
        System.out.println(f0("abcfghed"));
        System.out.println(f0("abnasnasab"));
        System.out.println(f0("najskaghkkjsfvjhbavbdfsan"));
        System.out.println(f0("jgbgdsjabkjdbvbdjabkjsavbkjbdsvkjbagfgafjdbv"));
        
        assert (f0("ab").equals("ab"));
        assert (f0("ba").equals("ab"));
        assert (f0("aa").equals("aa"));
        assert (f0("cba").equals("abc"));
        assert (f0("abababab").equals("aaaabbbb"));
        assert (f0("abcfghed").equals("abcdefgh"));
        assert (f0("abnasnasab").equals("aaaabbnnss"));
        assert (f0("najskaghkkjsfvjhbavbdfsan").equals("aaaabbdffghhjjjkkknnsssvv"));
        assert (f0("jgbgdsjabkjdbvbdjabkjsavbkjbdsvkjbagfgafjdbv").equals("aaaaabbbbbbbbbdddddffggggjjjjjjjjkkkksssvvvv"));
    }
}



